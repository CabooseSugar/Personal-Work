package exercise2;

public class DayException extends Exception {

    public DayException(){
        super("Invalid day, please re-enter.");
    }
}
