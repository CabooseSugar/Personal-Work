package exercise2;

public class YearException extends Exception{

    public YearException(){
        super("Invalid year, please re-enter.");
    }
}
