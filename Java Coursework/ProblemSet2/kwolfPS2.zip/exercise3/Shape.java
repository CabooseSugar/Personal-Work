package exercise3;

public interface Shape {
    // RETURNS AREA OF SHAPE
    double area();
}
