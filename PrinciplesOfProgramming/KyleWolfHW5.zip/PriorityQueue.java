public class PriorityQueue<T> {
    Node head;

    class Node {
        private int priority;
        private T data;
        private Node next;


        public Node(int priority, T data) {
            this.priority = priority;
            this.data = data;
        }

        public Node(int priority, T data, Node next) {
            this.priority = priority;
            this.data = data;
            this.next = next;
        }
    }

    public PriorityQueue insert(int priority, T data){
        if (head == null ){
            head = new Node(priority, data);
            return this;
        }

        if (priority > head.priority){
            head = new Node(priority, data, head);
            return this;
        }

        Node p = head;
        while(p.next != null && priority <= p.next.priority ){
            p = p.next;
        }
        p.next = new Node(priority, data, p.next);
        return this;
    }

    public T removeHighestElem(){
        if (head == null){
            return null;
        }

        T ret = head.data;
        head = head.next;
        return ret;
    }

    public T getHighestElem(){
        if (head == null){
            return null;
        }

        return head.data;
    }

    public int getHighestPriority(){
        if (head == null){
            return -1;
        }

        return head.priority;
    }

    public int getSize(){
        if (head == null){
            return 0;
        }

        int size = 1;
        Node p = head;
        while (p.next != null){
            p = p.next;
            size++;
        }
        return size;
    }



}
